﻿interface IAddToEnd
{
	string AddToEnd(string item);
}