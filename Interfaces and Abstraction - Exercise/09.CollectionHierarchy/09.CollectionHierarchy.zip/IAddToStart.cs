﻿public interface IAddToStart
{
	string AddToStart(string item);
}