﻿public interface IBox
{
    double CalculateSurfaceArea();
    double CalculateLateralSurfaceArea();
    double CalculateVolume();
}