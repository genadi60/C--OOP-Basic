﻿public interface IAnimalFactory
{
    void CreateAnimal();
}