﻿public interface ISpecialisedSoldier
{
}