﻿public interface IRemoveFromEnd
{
	string RemoveFromEnd();
}