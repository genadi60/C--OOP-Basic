﻿public interface ICitizen
{
    string GetId();
}