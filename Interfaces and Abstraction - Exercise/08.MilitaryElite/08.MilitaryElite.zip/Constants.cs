﻿public class Constants
{
    public const string FINISHED = "Finished";
    public const string IN_PROGRESS = "inProgress";
    public const string AIRFORCES = "Airforces";
    public const string MARINES = "Marines";
}