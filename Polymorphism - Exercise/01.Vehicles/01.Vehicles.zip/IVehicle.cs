﻿public interface IVehicle
{
    string Drive(double distance);
    void Refuel(double fuel);
}