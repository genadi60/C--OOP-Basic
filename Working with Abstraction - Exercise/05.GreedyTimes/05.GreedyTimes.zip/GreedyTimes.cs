﻿class GreedyTimes
{
    static void Main()
    {
        Engine engine = new EngineImpl();
        engine.Run();
    }
}