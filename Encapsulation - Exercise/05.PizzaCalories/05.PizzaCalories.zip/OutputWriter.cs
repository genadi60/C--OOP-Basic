﻿using System;

public class OutputWriter
{
	public void WriteLine(string input)
	{
		Console.WriteLine(input);
	}
}