﻿using System;

public class OutputWriter
{
    public void WriteLine(string output)
    {
        Console.WriteLine(output);
    }
}