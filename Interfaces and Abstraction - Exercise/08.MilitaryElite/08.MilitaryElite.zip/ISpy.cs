﻿public interface ISpy
{
}