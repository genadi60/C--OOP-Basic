﻿using System.Collections.Generic;

public interface ILeutenantGeneral
{
    void AddPrivate(int id, IPrivate soldier);
}