﻿public interface IVehicle
{
    void Drive(double distance);
    void Refuel(double fuel);
	void DriveEmpty(double distance);
}