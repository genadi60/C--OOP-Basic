﻿public interface IRemoveFromStart
{
	string RemoveFromStart();
}