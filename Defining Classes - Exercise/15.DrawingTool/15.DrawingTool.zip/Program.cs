﻿using System;

class Program
{
    static void Main()
    {
        var tool = new DrawingTool(Console.ReadLine());
    }
}