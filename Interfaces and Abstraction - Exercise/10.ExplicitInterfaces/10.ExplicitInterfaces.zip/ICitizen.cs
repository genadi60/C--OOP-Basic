﻿public interface ICitizen 
{
	string GetName();
}