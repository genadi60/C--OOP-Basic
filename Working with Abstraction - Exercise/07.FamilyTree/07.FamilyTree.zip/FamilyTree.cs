﻿using System;
using System.Collections.Generic;

class FamilyTree
{
    static void Main()
    {
        var parentsList = new List<string>();
        var childerList = new List<string>();
        var persons = new Dictionary<string, Person>();
        var targetPerson = Console.ReadLine();
        bool findByDate = false;
        if (Char.IsDigit(targetPerson[0]))
        {
            findByDate = true;
        }


        while (true)
        {
            var input = Console.ReadLine();
            if ("End" == input)
            {
                break;
            }

            if (input.Contains("-"))
            {
                var tokens = input.Split(" - ");
                var parent = tokens[0];
                var child = tokens[1];
                parentsList.Add(parent);
                childerList.Add(child);

                //if (Char.IsDigit(parent[0]))
                //{
                //    if (!personWithDate.ContainsKey(parent))
                //    {
                //        personWithDate[parent] = new Person();
                //    }

                //    firstParent.Birthday = parent;
                //    firstPerson.Birthday = parent;
                //    personWithDate[parent] = firstPerson;
                //}
                //else
                //{
                //    firstParent.Name = parent;
                //    firstPerson.Name = parent;
                //    personWithName[parent] = firstPerson;
                //}

                
            }
            else
            {
                var name = input.Substring(0, input.LastIndexOf(' '));
                var birthday = input.Substring(input.LastIndexOf(' ') + 1);
                
                if (!persons.ContainsKey(name))
                {
                    persons[name] = new Person();
                }

                persons[name].Name = name;
                persons[name].Birthday = birthday;
            }
        }

        for (int i = 0; i < parentsList.Count; i++)
        {
            var parent = new Parent();
            var child = new Child();
            if (Char.IsDigit(parentsList[i][0]))
            {
                
                foreach (Person person in persons.Values)
                {
                    if (parentsList[i] == person.Birthday)
                    {
                        parent.Name = person.Name;
                        parent.Birthday = person.Birthday;
                    }

                    if (findByDate)
                    {
                        if (targetPerson == person.Birthday)
                        {
                            targetPerson = person.Name;
                        }
                    }
                }
            }
            else
            {
                foreach (Person person in persons.Values)
                {
                    if (parentsList[i] == person.Name)
                    {
                        parent.Name = person.Name;
                        parent.Birthday = person.Birthday;
                    }
                }
            }

            if (Char.IsDigit(childerList[i][0]))
            {
                foreach (Person person in persons.Values)
                {
                    if (childerList[i] == person.Birthday)
                    {
                        child.Name = person.Name;
                        child.Birthday = person.Birthday;
                    }
                }
            }
            else
            {
                foreach (Person person in persons.Values)
                {
                    if (childerList[i] == person.Name)
                    {
                        child.Name = person.Name;
                        child.Birthday = person.Birthday;
                    }
                }
            }

            parent.Children.Add(child);
            child.Parents.Add(parent);
            foreach (Person person in persons.Values)
            {
                if (parent.Name == person.Name)
                {
                    person.Children.Add(child);
                }

                if (child.Name == person.Name)
                {
                    person.Parents.Add(parent);
                }
            }
        }

        foreach (Person person in persons.Values)
        {
            if (targetPerson == person.Name)
            {
                Console.WriteLine(person);
            }
        }
    }
}