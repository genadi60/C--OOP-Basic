﻿using System;

class InputReader
{
    public InputReader()
    {
    }

    public string ReadLine()
    {
        return Console.ReadLine();
    }
}