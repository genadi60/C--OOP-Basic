﻿interface IFunctionable
{
    string GetCalling(string phoneNumber);

    string GetBrowsing(string browser);
}