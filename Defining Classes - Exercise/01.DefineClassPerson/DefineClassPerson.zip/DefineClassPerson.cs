﻿class DefineClassPerson
{
    static void Main()
    {
        var firstPerson = new Person("Pesho", 20);
        var secondPerson = new Person("Gosho", 18);
        var thirdPerson = new Person("Stamat", 43);
    }
}