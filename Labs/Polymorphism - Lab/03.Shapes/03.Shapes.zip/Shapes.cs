﻿using System;

class Shapes
{
    static void Main()
    {
        
    }
}