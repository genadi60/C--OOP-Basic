﻿public interface ICitizen
{
    string GetBirthday();
}