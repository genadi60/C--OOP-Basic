﻿public interface IFerrari
{
    string PushBrakes();

    string PushGasPedal();
}