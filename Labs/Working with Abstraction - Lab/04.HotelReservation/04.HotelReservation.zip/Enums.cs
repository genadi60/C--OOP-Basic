﻿public class Enums
{
    public  enum Discount
    {
        None = 0,
        SecondVisit = 10,
        VIP = 20
    }

    public enum Season
    {
        Autumn = 1,
        Spring = 2,
        Winter = 3,
        Summer = 4
    }
}