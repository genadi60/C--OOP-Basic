﻿public interface IAnimal
{
    string ProduceSound();
}