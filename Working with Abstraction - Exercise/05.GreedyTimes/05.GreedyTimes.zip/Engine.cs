﻿interface Engine
{
    void Run();
}