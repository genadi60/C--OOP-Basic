﻿class CreatingConstructors
{
    static void Main()
    {
        Person person = new Person();
    }
}