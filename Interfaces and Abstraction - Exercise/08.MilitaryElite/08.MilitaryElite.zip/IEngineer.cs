﻿using System.Collections.Generic;

public interface IEngineer
{
    void AddRepair(IRepair repair);
}