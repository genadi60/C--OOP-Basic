﻿using System;

class MilitaryElite
{
    static void Main()
    {
        IEngine engine = new Engine();
        engine.Run();
    }
}