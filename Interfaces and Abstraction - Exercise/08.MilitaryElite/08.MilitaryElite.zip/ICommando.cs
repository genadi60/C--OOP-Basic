﻿public interface ICommando
{
    void AddMission(IMission mission);
}