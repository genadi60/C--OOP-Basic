﻿class FoodShortage
{
    static void Main()
    {
        IEngine engine = new Engine();
        engine.Run();
    }
}