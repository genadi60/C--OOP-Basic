﻿class PersonClass
{
    static void Main()
    {
        
    }
}